@extends('layouts.app')

@section('content')
@if(Auth::guest())
<div class="container">
	<div class="panel panel-default">
		<div class="panel-body">
			<h1>No has iniciado sesión</h1>
		</div>
	</div>
</div>
@else
<div class="container">
	<h1>Filtrar licitaciones por fecha</h1>
	<div class="panel panel-default">
		<div class="panel-body">


			{!! Form::open(array('url' => 'buscado', 'class' =>'form-group', 'method' => 'get')) !!}
					{!! Form::label('Fecha') !!}
					{!! Form::date('fecha', \Carbon\Carbon::now(), array('required', 'class' => 'form-control', 'placeholder' => 'Ingresa fecha', 'max' =>\Carbon\Carbon::now()->format('Y-m-d') )) !!}
					{!! Form::submit('Filtrar') !!}
			{!! Form::close() !!}
		</div>
	</div>
</div>
@endif
@endsection