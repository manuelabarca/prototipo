@extends('layouts.app')

@section('content')
<div class="container">
	<h1>Licitaciones</h1>
	@foreach ($licitacion->Listado as $lista)
	<div class="panel panel-default">	
		<div class="panel-body">	
			<table>
				<tr>
					<td>
						Nombre: 
					</td>
					<td>
						{{ $lista->Nombre }}
					</td>						
				</tr>		
				<tr>
					<td>
						Estado: 
					</td>
					<td>
						{{ $lista->Estado }}
					</td>
				</tr>					
					
			</table>	
		</div>
	</div>
	@endforeach
</div>
@endsection