@extends('layouts.app')

@section('content')
@if(Auth::guest())
<div class="container">
	<div class="panel panel-default">
		<div class="panel-body">
			<h1>No has iniciado sesión</h1>
		</div>
	</div>
</div>
@else
<div class="container">
	<h1>Licitaciones, en estado de publicada</h1>

	@foreach ($licitaciones->Listado as $licitacion)
		@if ($licitacion->CodigoEstado == '5')
		{{-- expr --}}
	<div class="panel panel-default">
		<div class="panel-body">		
		{{ $codigo =$licitacion->CodigoExterno }}
		<a href="{{ url('/') }}/licitacion/{{$codigo}}">
			{{ $licitacion->Nombre }}
		</a>
		<div class="pull-right">
		<ul class="dropdown">
			<li><a href="licitacion/{{$codigo}}">Guardar en historial</a></li>
			<li><a href="">Crear notificación</a></li>
		</ul>
			
		</div>
		</div>
	</div>
		@endif
	@endforeach
</div>
@endif
@endsection