

<?php $__env->startSection('content'); ?>
<div class="container">
	<h1>Licitaciones</h1>
	<?php $__currentLoopData = $licitacion->Listado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lista): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="panel panel-default">	
		<div class="panel-body">	
			<table>
				<tr>
					<td>
						Nombre: 
					</td>
					<td>
						<?php echo e($lista->Nombre); ?>

					</td>						
				</tr>		
				<tr>
					<td>
						Estado: 
					</td>
					<td>
						<?php echo e($lista->Estado); ?>

					</td>
				</tr>					
					
			</table>	
		</div>
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>