<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" href="/css/app.css">
	<title>LicitApp</title>
</head>
<body>
<div class="container">
	<h1>Licitaciones</h1>
	<div class="panel panel-default">	
		<div class="panel-body">	
			<table>
				<tr>
					<td>
						Fecha: 
					</td>
					<td>
						<a href="busqueda/<?php echo e($fechas); ?>"><?php echo e($fechas); ?></a>
					</td>						
				</tr>	
			</table>		
		</div>
	</div>
</div>
</body>
</html>