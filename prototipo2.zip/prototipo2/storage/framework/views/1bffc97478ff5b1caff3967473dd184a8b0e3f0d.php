

<?php $__env->startSection('content'); ?>
<?php if(Auth::guest()): ?>
<div class="container">
	<div class="panel panel-default">
		<div class="panel-body">
			<h1>No has iniciado sesión</h1>
		</div>
	</div>
</div>
<?php else: ?>
<div class="container">
	<h1>Licitaciones, en estado de publicada</h1>

	<?php $__currentLoopData = $licitaciones->Listado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $licitacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php if($licitacion->CodigoEstado == '5'): ?>
		
	<div class="panel panel-default">
		<div class="panel-body">		
		<?php echo e($codigo =$licitacion->CodigoExterno); ?>

		<a href="<?php echo e(url('/')); ?>/licitacion/<?php echo e($codigo); ?>">
			<?php echo e($licitacion->Nombre); ?>

		</a>
		<div class="pull-right">
		<ul class="dropdown">
			<li><a href="licitacion/<?php echo e($codigo); ?>">Guardar en historial</a></li>
			<li><a href="">Crear notificación</a></li>
		</ul>
			
		</div>
		</div>
	</div>
		<?php endif; ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>