

<?php $__env->startSection('content'); ?>
<?php if(Auth::guest()): ?>
<div class="container">
	<div class="panel panel-default">
		<div class="panel-body">
			<h1>No has iniciado sesión</h1>
		</div>
	</div>
</div>
<?php else: ?>
<div class="container">
	<h1>Filtrar licitaciones por fecha</h1>
	<div class="panel panel-default">
		<div class="panel-body">


			<?php echo Form::open(array('url' => 'buscado', 'class' =>'form-group', 'method' => 'get')); ?>

					<?php echo Form::label('Fecha'); ?>

					<?php echo Form::date('fecha', \Carbon\Carbon::now(), array('required', 'class' => 'form-control', 'placeholder' => 'Ingresa fecha', 'max' =>\Carbon\Carbon::now()->format('Y-m-d') )); ?>

					<?php echo Form::submit('Filtrar'); ?>

			<?php echo Form::close(); ?>

		</div>
	</div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>