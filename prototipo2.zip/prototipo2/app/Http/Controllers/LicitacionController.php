<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use GuzzleHttp\Client;
use Carbon\Carbon;

class LicitacionController extends Controller
{
    
	public function filtrar()
	{
		return view('admin.busqueda.filtrar');		
	}



    public function busqueda(Request $request)
    {
	    $client = new Client([
	    // Base URI is used with relative requests
	    'base_uri' => 'http://api.mercadopublico.cl',
	    // You can set any number of default request options.
	    'timeout'  => 2.0,
		]);

	    $fecha = $request->get('fecha');
	    $date = new Carbon($fecha);
	    $date = $date->format('d-m-Y');
	    $date = str_replace('-','',$date);

	    $response = $client -> request('GET', "servicios/v1/publico/licitaciones.json?fecha={$date}&ticket=F8537A18-6766-4DEF-9E59-426B4FEE2844");

	    $licitaciones = json_decode( ($response ->getBody() -> getContents()) );

	    return view('admin.busqueda.buscado', compact('licitaciones'));
    }

    public function mostrar($codigo)
    {
		$client = new Client([
	    // Base URI is used with relative requests
	    'base_uri' => 'http://api.mercadopublico.cl',
	    // You can set any number of default request options.
	    'timeout'  => 2.0,
		]);

	    $response = $client -> request('GET', "servicios/v1/publico/licitaciones.json?codigo={$codigo}&ticket=F8537A18-6766-4DEF-9E59-426B4FEE2844");

	    $licitacion = json_decode( ($response ->getBody() -> getContents()) );

	    return view('admin.busqueda.mostrar', compact('licitacion'));
    }
}
