<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('filtrar', ['uses' => 'LicitacionController@filtrar']);
Route::get('buscado', ['uses' =>  'LicitacionController@busqueda']);
//Route::get('busqueda/{fechas}', 'LicitacionController@busqueda');
Route::get('licitacion/{codigo}', 'LicitacionController@mostrar');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
